Important Reminder: I have heard rumors that some individuals are trying to make money by distributing this module. It made me very upset. Please note that this software distributing under GPL V3 (except provided .APK) and any commercial activity with this is not allowed! 
If you paid money for it, then you were deceived, the module is completely free!

Magisk module fixing DriveDroid on new android devices. Based on this script https://gist.github.com/mmtrt/5dfbd2559ea988dfbe56277347ac6c96
This module tested on Xiaomi Mi Note 10 lite. You can replace service.sh in this module with your own modified script.


Module was currently tested on folowing devices:
1) Xiaomi Mi Note 10 lite (toco, PixelOS - Android 13)
2) Realme XT (RMX1921)
3) Razer Phone (Project Cheryl, LineageOS 19.1)
4) Google Pixel 5a 5G (Barbet, Stock Android 13)
5) Xiaomi Mi 9T (davinci, RiceDroid, A13)
6) Samsung Galaxy A22s 5G (a22x, Stock Android 11)
7) Doogie s98pro (Stock Android)
8) Redmi Note 7 (Lavender, DerpFest Tango - Android 13)
9) Samsung s21 Ultra (BeyondROM 4.4 DWA4, Android 13) - partially works, but cable disconnection during mounting will cause reboot. Troubleshooting is now in progress.
10) Google Pixel 7 pro (Stock Android)

Для русскоязычных пользователей модуль так же доступен здесь https://4pda.to/forum/index.php?s=&showtopic=915158&view=findpost&p=120972972 . Там так же можно внести предложения или задать вопросы.
Русскоязычная версия модуля НЕ СОВМЕСТИМА с github версией. Что это значит? Это значит что поверх англоязычного модуля русскоязычный ставить настоятельно не рекомендую - это может привести к различным мелким проблемам. Сначала удаляем старую версию, перезагружается, ставим новую. Обновлять поверх одного и того же языка - можно.
